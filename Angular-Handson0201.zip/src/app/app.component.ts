import {Component} from '@angular/core';
import {UsersModel} from "../users.model";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Angular-Handson0201';

  dataLoaded: boolean = false;
  users: UsersModel[] = [];

  onDataFetch() {
    fetch("https://reqres.in/api/users")
      .then(res => res.json())
      .then(users => {
        this.users = users.data;
        this.dataLoaded = true;
      });
  }
}
